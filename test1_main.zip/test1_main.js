//select rows
const rows=document.querryselectionAll('rows')
//select Buy Seats
const buyseats = document.querryselector ('Buy Seats')
// select Confirm
const comfirm = document.querryselector ('Confirm')
